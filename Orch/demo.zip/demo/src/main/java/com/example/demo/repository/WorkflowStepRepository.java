package com.example.demo.repository;
import com.example.demo.model.Workflow;
import com.example.demo.model.WorkflowStep;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WorkflowStepRepository extends JpaRepository<WorkflowStep, Long> {
    Optional<WorkflowStep> findByWorkflowAndStepOrder(Workflow workflow, int stepOrder);
    List<WorkflowStep> findByWorkflow_WorkflowId(Long workflowId);
    List<WorkflowStep> findByWorkflow_WorkflowIdAndStepOrder(Long workflowId, int stepOrder);

   // List<WorkflowStep> findByWorkflowProcess_WorkflowProcessId(Long workflowProcessId);
}
