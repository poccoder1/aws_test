package com.example.demo.service;

import com.example.demo.dto.ProcessDTO;
import com.example.demo.mapper.ProcessMapper;
import com.example.demo.model.Process;
import com.example.demo.repository.ProcessRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProcessService {

    private static final Logger logger = LoggerFactory.getLogger(ProcessService.class);
    private final ProcessRepository processRepository;
    private final ProcessMapper processMapper;

    public ProcessService(ProcessRepository processRepository, ProcessMapper processMapper) {
        this.processRepository = processRepository;
        this.processMapper = processMapper;
    }

    public List<ProcessDTO> getAllProcesses() {
        logger.info("Retrieving all processes");
        return processRepository.findAll().stream()
                .map(processMapper::toDto)
                .collect(Collectors.toList());
    }

    public ProcessDTO getProcessById(Long id) {
        logger.info("Retrieving process with ID: {}", id);
        return processRepository.findById(id)
                .map(processMapper::toDto)
                .orElse(null);
    }

    public ProcessDTO createProcess(ProcessDTO processDTO) {
        logger.info("Creating new process: {}", processDTO);
        Process process = processMapper.toEntity(processDTO);
        Process savedProcess = processRepository.save(process);
        return processMapper.toDto(savedProcess);
    }

    public ProcessDTO updateProcess(Long id, ProcessDTO processDTO) {
        logger.info("Updating process with ID: {}", id);
        return processRepository.findById(id)
                .map(existingProcess -> {
                    existingProcess.setProcessName(processDTO.getProcessName());
                    existingProcess.setDescription(processDTO.getDescription());
                    Process updatedProcess = processRepository.save(existingProcess);
                    return processMapper.toDto(updatedProcess);
                })
                .orElse(null);
    }

    public boolean deleteProcess(Long id) {
        logger.info("Deleting process with ID: {}", id);
        if (processRepository.existsById(id)) {
            processRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
