package com.example.demo.dto;

import java.time.LocalDateTime;

public class FileProcessStatusDTO {
    private Long processId;           // The ID of the Process
    private String inputFileType;     // The input file type
    private String status;             // The status of the file process
    private LocalDateTime startTime;   // The start time of the process
    private LocalDateTime endTime;     // The end time of the process

    // Getters and Setters
    public Long getProcessId() {
        return processId;
    }

    public void setProcessId(Long processId) {
        this.processId = processId;
    }

    public String getInputFileType() {
        return inputFileType;
    }

    public void setInputFileType(String inputFileType) {
        this.inputFileType = inputFileType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }
}
