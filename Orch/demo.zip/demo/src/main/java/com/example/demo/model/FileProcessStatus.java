package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Data
public class FileProcessStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "file_process_id")
    private Long fileProcessId;

    @Column(name = "file_download_id", nullable = false)
    private UUID fileDownloadId;

    @Column(name = "batch_id", nullable = false)
    private String batchId;

    @ManyToOne
    @JoinColumn(name = "workflow_process_id", nullable = false)
    private WorkflowProcess workflowProcess;

    @Column(name = "input_file_type", nullable = false)
    private String inputFileType;

    @Column(name = "status", nullable = false)
    private String status;

    @Column(name = "start_time")
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "workflow_id", referencedColumnName = "workflow_id"),
            @JoinColumn(name = "current_step_sequence", referencedColumnName = "step_order")
    })
    private WorkflowStep currentStep;

    @Column(name = "error_message")
    private String errorMessage;

    public FileProcessStatus() {}

    public FileProcessStatus(UUID fileDownloadId, String batchId, WorkflowProcess workflowProcess,
                             String inputFileType, String status, LocalDateTime startTime,
                             LocalDateTime endTime, WorkflowStep currentStep, String errorMessage) {
        this.fileDownloadId = fileDownloadId;
        this.batchId = batchId;
        this.workflowProcess = workflowProcess;
        this.inputFileType = inputFileType;
        this.status = status;
        this.startTime = startTime;
        this.endTime = endTime;
        this.currentStep = currentStep;
        this.errorMessage = errorMessage;
    }
}
