package com.example.demo.service;

import com.example.demo.model.*;
import com.example.demo.model.Process;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class DataInitializationService {

    @Autowired
    private WorkflowRepository workflowRepository;
    @Autowired
    private ProcessRepository processRepository;
    @Autowired
    private WorkflowProcessRepository workflowProcessRepository;
    @Autowired
    private WorkflowStepRepository workflowStepRepository;
    @Autowired
    private FileTypeRelationshipRepository fileTypeRelationshipRepository;
    @Autowired
    private FileProcessStatusRepository fileProcessStatusRepository;

    @PostConstruct
    public void initData() {
        // Initialize workflows
        Workflow wf1 = new Workflow("GFD->FORMATTER->GCS3", "Workflow 1 description");
        Workflow wf2 = new Workflow("GFD->FORMATTER->GCS3->SHARE DRIVE->GFP->GCS3", "Workflow 2 description");
        Workflow wf3 = new Workflow("GFD->FORMATTER->GCS3->SHARE DRIVE->GFP->HOST PUBLISHER", "Workflow 3 description");
        Workflow wf4 = new Workflow("GFD->FORMATTER->GCS3->SHARE DRIVE->GFP->EWS", "Workflow 4 description");
        workflowRepository.saveAll(List.of(wf1, wf2, wf3, wf4));

        // Initialize processes
        Process process1 = new Process("LCH USER REPORT", "Process 1 description");
        Process process2 = new Process("LME USER REPORT", "Process 2 description");
        Process process3 = new Process("EUREX_TRAN", "Process 3 description");
        Process process4 = new Process("EUREX_POS", "Process 4 description");
        processRepository.saveAll(List.of(process1, process2, process3, process4));

        // Initialize workflow processes
        WorkflowProcess wfp1 = new WorkflowProcess(wf1, process1);
        WorkflowProcess wfp2 = new WorkflowProcess(wf2, process2);
        WorkflowProcess wfp3 = new WorkflowProcess(wf2, process3);
        WorkflowProcess wfp4 = new WorkflowProcess(wf3, process4);
        workflowProcessRepository.saveAll(List.of(wfp1, wfp2, wfp3, wfp4));

        // Initialize workflow steps
        List<WorkflowStep> steps = List.of(
                new WorkflowStep(wf1, 0, "GFD", "Step 1 description"),
                new WorkflowStep(wf1, 1, "GFF", "Step 2 description"),
                new WorkflowStep(wf1, 2, "GCS3", "Step 3 description"),
                new WorkflowStep(wf2, 0, "GFD", "Step 4 description"),
                new WorkflowStep(wf2, 1, "GFF", "Step 5 description"),
                new WorkflowStep(wf2, 2, "GCS3", "Step 6 description"),
                new WorkflowStep(wf2, 3, "GCS3", "Step 7 description"),
                new WorkflowStep(wf2, 4, "SHARE DRIVE", "Step 8 description"),
                new WorkflowStep(wf2, 5, "GFP", "Step 9 description"),
                new WorkflowStep(wf2, 6, "GCS3", "Step 10 description")
        );
        workflowStepRepository.saveAll(steps);

        // Initialize file type relationships
        List<FileTypeRelationship> fileTypeRelationships = List.of(
                new FileTypeRelationship(wfp1, "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", 0),
                new FileTypeRelationship(wfp1, "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", 1),
                new FileTypeRelationship(wfp1, "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", 2),
                new FileTypeRelationship(wfp3, "EUREX_INPUT_00RPTCB012JPDFR_CSV_ZIP", "EUREX INPUT DORPTCB012JPDFR_CSV_ZIP", 0),
                new FileTypeRelationship(wfp3, "EUREX_INPUT_00RPTCB012JPDFR_CSV_ZIP", "RPTCB012JPDFR_TRADES_CSV", 1),
                new FileTypeRelationship(wfp3, "RPTCB012JPDFR_TRADES_CSV", "RPTCB012JPDFR_TRADES_CSV", 2),
                new FileTypeRelationship(wfp3, "RPTCB012JPDFR_TRADES_CSV", "RPTCB012JPDFR_TRADES_CSV", 3),
                new FileTypeRelationship(wfp3, "RPTCB012JPDFR_TRADES_CSV", "EUREX_TRANSACTIONS_AG_CSV", 4),
                new FileTypeRelationship(wfp3, "RPTCB012JPDFR_TRADES_CSV", "EUREX_TRANSACTIONS_PLC_CSV", 4),
                new FileTypeRelationship(wfp3, "EUREX_TRANSACTIONS_AG_CSV", "EUREX_TRANSACTIONS_AG_CSV", 5),
                new FileTypeRelationship(wfp3, "EUREX_TRANSACTIONS_PLC_CSV", "EUREX_TRANSACTIONS_PLC_CSV", 5),
                new FileTypeRelationship(wfp4, "CUREX_INPUT_00RPTCB012JPDFR_CSV_ZIP", "EUREX INPUT_00RPTCB012JPDFR_CSV_ZIP", 0),
                new FileTypeRelationship(wfp4, "EUREX_INPUT_00RPTCB012JPDFR_CSV_ZIP", "RPTCB012JPDFR_POSITIONS_CSV", 1),
                new FileTypeRelationship(wfp4, "RPTCB012JPDFR_POSITIONS_CSV", "RPTCB012JPDF_POSITIONS_CSV", 2),
                new FileTypeRelationship(wfp4, "RPTCB012JPDFR_POSITIONS_CSV", "RPTCB012JPDFR_POSITIONS_CSV", 3),
                new FileTypeRelationship(wfp4, "RPTCB012JPDFR_POSITIONS_CSV", "EUREX_POS_AG", 4),
                new FileTypeRelationship(wfp4, "RPTCB012JPDFR_POSITIONS_CSV", "EUREX_POS_PLC", 4),
                new FileTypeRelationship(wfp4, "EUREX_POS_AG", "EUREX_POS_AG", 5),
                new FileTypeRelationship(wfp4, "EUREX_POS_PLC", "EUREX_POS_PLC", 5)
        );
        fileTypeRelationshipRepository.saveAll(fileTypeRelationships);

        // Retrieve a sample WorkflowProcess and WorkflowStep for FileProcessStatus example data
        WorkflowProcess workflowProcess = workflowProcessRepository.findById(1L).orElseThrow();
        WorkflowStep wfStep0 = workflowStepRepository.findByWorkflowAndStepOrder(workflowProcess.getWorkflow(), 0).orElseThrow();
        WorkflowStep wfStep1 = workflowStepRepository.findByWorkflowAndStepOrder(workflowProcess.getWorkflow(), 1).orElseThrow();
        WorkflowStep wfStep2 = workflowStepRepository.findByWorkflowAndStepOrder(workflowProcess.getWorkflow(), 2).orElseThrow();

        // Example data for the FILE_PROCESS_STATUS table
        List<FileProcessStatus> fileProcessStatuses = List.of(
                new FileProcessStatus(UUID.randomUUID(), "LCH-REPORTS", workflowProcess, "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", "COMPLETED", LocalDateTime.of(2024, 10, 27, 12, 0, 0), LocalDateTime.of(2024, 10, 27, 12, 5, 0), wfStep0, null),
                new FileProcessStatus(UUID.randomUUID(), "LCH-REPORTS", workflowProcess, "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", "COMPLETED", LocalDateTime.of(2024, 10, 27, 12, 5, 5), LocalDateTime.of(2024, 10, 27, 12, 5, 20), wfStep1, null),
                new FileProcessStatus(UUID.randomUUID(), "LCH-REPORTS", workflowProcess, "JPJ_REP00022_Yesterday_Cover_Account_Postings_TXT", "COMPLETED", LocalDateTime.of(2024, 10, 27, 12, 5, 25), LocalDateTime.of(2024, 10, 27, 12, 5, 30), wfStep2, null)
        );
        fileProcessStatusRepository.saveAll(fileProcessStatuses);
    }
}
