package com.example.demo.service;

import com.example.demo.dto.FileTypeRelationshipDTO; // Make sure to import this
import com.example.demo.dto.FileTypeRelationshipResponseDTO;
import com.example.demo.model.FileTypeRelationship;
import com.example.demo.model.WorkflowProcess;
import com.example.demo.model.WorkflowStep;
import com.example.demo.repository.FileTypeRelationshipRepository;
import com.example.demo.repository.WorkflowStepRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FileTypeRelationshipService {

    private static final Logger logger = LoggerFactory.getLogger(FileTypeRelationshipService.class);
    private final FileTypeRelationshipRepository fileTypeRelationshipRepository;
    private final WorkflowStepRepository workflowStepRepository;

    public FileTypeRelationshipService(FileTypeRelationshipRepository fileTypeRelationshipRepository,
                                       WorkflowStepRepository workflowStepRepository) {
        this.fileTypeRelationshipRepository = fileTypeRelationshipRepository;
        this.workflowStepRepository = workflowStepRepository;
    }

    public List<FileTypeRelationship> getAllFileTypeRelationships() {
        logger.info("Retrieving all file type relationships");
        return fileTypeRelationshipRepository.findAll();
    }

    public FileTypeRelationship getFileTypeRelationshipById(Long id) {
        logger.info("Fetching file type relationship by ID: {}", id);
        return fileTypeRelationshipRepository.findById(id).orElse(null);
    }

    public List<FileTypeRelationship> getFileTypeRelationshipsByWorkflowProcessId(Long workflowProcessId) {
        logger.info("Fetching file type relationships by workflow process ID: {}", workflowProcessId);
        return fileTypeRelationshipRepository.findByWorkflowProcess_WorkflowProcessId(workflowProcessId);
    }

    public FileTypeRelationship createFileTypeRelationship(FileTypeRelationship fileTypeRelationship) {
        logger.info("Creating new file type relationship: {}", fileTypeRelationship);
        return fileTypeRelationshipRepository.save(fileTypeRelationship);
    }

    public FileTypeRelationship updateFileTypeRelationship(Long id, FileTypeRelationshipDTO dto) {
        FileTypeRelationship existingRelationship = fileTypeRelationshipRepository.findById(id).orElse(null);
        if (existingRelationship == null) {
            return null;
        }
        existingRelationship.setInputFileType(dto.getInputFileType());
        existingRelationship.setOutputFileType(dto.getOutputFileType());
        existingRelationship.setStepOrder(dto.getStepOrder());
        return fileTypeRelationshipRepository.save(existingRelationship);
    }

    public boolean deleteFileTypeRelationship(Long id) {
        if (fileTypeRelationshipRepository.existsById(id)) {
            logger.info("Deleting file type relationship with ID: {}", id);
            fileTypeRelationshipRepository.deleteById(id);
            return true;
        } else {
            logger.warn("File type relationship with ID: {} not found for deletion", id);
            return false;
        }
    }
//    public List<FileTypeRelationshipResponseDTO> getDetailsByInputFileType(String inputFileType) {
//        List<FileTypeRelationship> relationships = fileTypeRelationshipRepository.findByInputFileType(inputFileType);
//
//        return relationships.stream().map(relationship -> {
//            WorkflowStep workflowStep = workflowStepRepository
//                    .findByWorkflowProcess_WorkflowProcessId(relationship.getWorkflowProcess().getWorkflowProcessId())
//                    .stream() // Convert to stream
//                    .findFirst() // Get the first WorkflowStep (if exists)
//                    .orElse(null); // Handle the case where no WorkflowStep is found
//
//            return mapToResponseDTO(relationship, workflowStep);
//        }).collect(Collectors.toList());
//    }
//
//    private FileTypeRelationshipResponseDTO mapToResponseDTO(FileTypeRelationship relationship, WorkflowStep workflowStep) {
//        // Map the fields accordingly, ensure to handle null values if workflowStep is null
//        FileTypeRelationshipResponseDTO dto = new FileTypeRelationshipResponseDTO();
//        dto.setInputFileType(relationship.getInputFileType());
//        dto.setOutputFileType(relationship.getOutputFileType());
//        dto.setStepOrder(relationship.getStepOrder());
//        dto.setWorkflowProcessId(relationship.getWorkflowProcess().getWorkflowProcessId());
//        if (workflowStep != null) {
//            dto.setServiceName(workflowStep.getServiceName());
//            // You can also set other fields if needed
//        }
//        // Assume you have a method to fetch the process name from the Process entity
//        dto.setProcessName(relationship.getWorkflowProcess().getProcess().getProcessName());
//
//        return dto;
//    }

    public List<FileTypeRelationshipResponseDTO> getDetailsByInputFileType(String inputFileType) {
        // Log the input parameter
        logger.info("Fetching details for inputFileType: {}", inputFileType);

        // Step 1: Get the workflowProcessId for the given inputFileType
        List<FileTypeRelationship> relationships = fileTypeRelationshipRepository.findByInputFileType(inputFileType);

        // If no relationships found for the input file type
        if (relationships.isEmpty()) {
            logger.warn("No relationships found for inputFileType: {}", inputFileType);
            return Collections.emptyList(); // Return empty list if no relationships found
        }

        // Extract workflowProcessIds from the found relationships
        List<Long> workflowProcessIds = relationships.stream()
                .map(relationship -> relationship.getWorkflowProcess().getWorkflowProcessId())
                .collect(Collectors.toList());

        // Step 2: Get all FileTypeRelationships with the extracted workflowProcessIds
        List<FileTypeRelationship> allRelationships = fileTypeRelationshipRepository
                .findByWorkflowProcess_WorkflowProcessIdIn(workflowProcessIds);

        // Log the number of relationships found
        logger.info("Found {} FileTypeRelationships for workflowProcessIds: {}", allRelationships.size(), workflowProcessIds.size());

        // Step 3: Create a DTO list and fill in the details
        List<FileTypeRelationshipResponseDTO> responseDTOs = new ArrayList<>();

        for (FileTypeRelationship relationship : allRelationships) {
            // Get the workflowId from the WorkflowProcess
            Long workflowId = relationship.getWorkflowProcess().getWorkflow().getWorkflowId();
            int stepOrder = relationship.getStepOrder();

            // Step 4: Get the corresponding WorkflowStep using workflowId and stepOrder
            List<WorkflowStep> workflowSteps = workflowStepRepository.findByWorkflow_WorkflowIdAndStepOrder(workflowId, stepOrder);

            // Assuming we want the first matching WorkflowStep based on the criteria
            Optional<WorkflowStep> matchingStep = workflowSteps.stream()
                    .findFirst();

            // Map the relationship and matching step to DTO
            FileTypeRelationshipResponseDTO dto = mapToResponseDTO(relationship, matchingStep.orElse(null));
            responseDTOs.add(dto);
        }

        return responseDTOs;
    }


    private FileTypeRelationshipResponseDTO mapToResponseDTO(FileTypeRelationship relationship, WorkflowStep workflowStep) {
        FileTypeRelationshipResponseDTO dto = new FileTypeRelationshipResponseDTO();
        dto.setInputFileType(relationship.getInputFileType());
        dto.setOutputFileType(relationship.getOutputFileType());
        dto.setStepOrder(relationship.getStepOrder());
        dto.setWorkflowProcessId(relationship.getWorkflowProcess().getWorkflowProcessId());
        if (workflowStep != null) {
            dto.setServiceName(workflowStep.getServiceName()); // Get the service name from the WorkflowStep
        }
        // You can also set other fields if needed
        dto.setProcessName(relationship.getWorkflowProcess().getProcess().getProcessName());

        return dto;
    }


}
