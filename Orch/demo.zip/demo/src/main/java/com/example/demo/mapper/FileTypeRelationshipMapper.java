package com.example.demo.mapper;

import com.example.demo.dto.FileTypeRelationshipDTO;
import com.example.demo.model.FileTypeRelationship;
import com.example.demo.model.WorkflowProcess;
import com.example.demo.repository.WorkflowProcessRepository; // Import the WorkflowProcessRepository
import org.springframework.stereotype.Component;

@Component
public class FileTypeRelationshipMapper {

    private final WorkflowProcessRepository workflowProcessRepository;

    public FileTypeRelationshipMapper(WorkflowProcessRepository workflowProcessRepository) {
        this.workflowProcessRepository = workflowProcessRepository;
    }

    public FileTypeRelationshipDTO toDTO(FileTypeRelationship fileTypeRelationship) {
        if (fileTypeRelationship == null) {
            return null;
        }
        FileTypeRelationshipDTO dto = new FileTypeRelationshipDTO();
        dto.setFtRelationId(fileTypeRelationship.getFtRelationId());
        dto.setInputFileType(fileTypeRelationship.getInputFileType());
        dto.setOutputFileType(fileTypeRelationship.getOutputFileType());
        dto.setStepOrder(fileTypeRelationship.getStepOrder());
        dto.setWorkflowProcessId(fileTypeRelationship.getWorkflowProcess().getWorkflowProcessId());
        return dto;
    }

    public FileTypeRelationship toEntity(FileTypeRelationshipDTO dto) {
        if (dto == null) {
            return null;
        }

        // Retrieve the WorkflowProcess entity from the repository using the workflowProcessId from the DTO
        WorkflowProcess workflowProcess = workflowProcessRepository.findById(dto.getWorkflowProcessId())
                .orElseThrow(() -> new IllegalArgumentException("WorkflowProcess not found with ID: " + dto.getWorkflowProcessId()));

        FileTypeRelationship fileTypeRelationship = new FileTypeRelationship();
        fileTypeRelationship.setFtRelationId(dto.getFtRelationId()); // This can be null for new entities
        fileTypeRelationship.setWorkflowProcess(workflowProcess);
        fileTypeRelationship.setInputFileType(dto.getInputFileType());
        fileTypeRelationship.setOutputFileType(dto.getOutputFileType());
        fileTypeRelationship.setStepOrder(dto.getStepOrder());
        return fileTypeRelationship;
    }
}
