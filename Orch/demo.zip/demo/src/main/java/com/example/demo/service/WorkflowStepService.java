package com.example.demo.service;

import com.example.demo.dto.WorkflowStepDTO;
import com.example.demo.mapper.WorkflowStepMapper;
import com.example.demo.model.WorkflowStep;
import com.example.demo.repository.WorkflowStepRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WorkflowStepService {

    private static final Logger logger = LoggerFactory.getLogger(WorkflowStepService.class);
    private final WorkflowStepRepository workflowStepRepository;
    private final WorkflowStepMapper workflowStepMapper;

    public WorkflowStepService(WorkflowStepRepository workflowStepRepository, WorkflowStepMapper workflowStepMapper) {
        this.workflowStepRepository = workflowStepRepository;
        this.workflowStepMapper = workflowStepMapper;
    }

    public List<WorkflowStep> getAllWorkflowSteps() {
        logger.info("Retrieving all workflow steps");
        return workflowStepRepository.findAll();
    }

    public WorkflowStep getWorkflowStepById(Long id) {
        logger.info("Retrieving workflow step by ID: {}", id);
        return workflowStepRepository.findById(id).orElse(null);
    }

    public WorkflowStep createWorkflowStep(WorkflowStep workflowStep) {
        logger.info("Creating new workflow step: {}", workflowStep);
        return workflowStepRepository.save(workflowStep);
    }

    public WorkflowStepDTO updateWorkflowStep(Long id, WorkflowStep workflowStep) {
        logger.info("Updating workflow step with ID: {}", id);
        if (!workflowStepRepository.existsById(id)) {
            return null;
        }
        workflowStep.setWorkflowStepId(id);
        return workflowStepMapper.toDTO(workflowStepRepository.save(workflowStep));
    }

    public boolean deleteWorkflowStep(Long id) {
        logger.info("Deleting workflow step with ID: {}", id);
        if (workflowStepRepository.existsById(id)) {
            workflowStepRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<WorkflowStepDTO> getWorkflowStepsByWorkflowId(Long workflowId) {
        logger.info("Fetching workflow steps for workflow ID: {}", workflowId);
        List<WorkflowStep> steps = workflowStepRepository.findByWorkflow_WorkflowId(workflowId);
        return steps.stream().map(workflowStepMapper::toDTO).collect(Collectors.toList());
    }
}
