package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

@Entity
@Data
public class Workflow {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "workflow_id")
    private Long workflowId;

    @Column(name = "workflow_name")
    private String workflowName;

    @Column(name = "description")
    private String description;

    @OneToMany(mappedBy = "workflow", cascade = CascadeType.ALL)
    private List<WorkflowProcess> workflowProcesses;

    @OneToMany(mappedBy = "workflow", cascade = CascadeType.ALL)
    private List<WorkflowStep> workflowSteps;

    public Workflow() {}

    public Workflow(Long workflowId, String workflowName, String description) {
        this.workflowId = workflowId;
        this.workflowName = workflowName;
        this.description = description;
    }

    public Workflow(String workflowName, String description) {
        this.workflowName = workflowName;
        this.description = description;
    }
}
