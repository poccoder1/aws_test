package com.example.demo.repository;

import com.example.demo.model.FileProcessStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FileProcessStatusRepository extends JpaRepository<FileProcessStatus, Long> {
    //List<FileProcessStatus> findByWorkflowProcessProcessId(Long processId);
   List<FileProcessStatus> findByWorkflowProcessProcessProcessId(Long processId);


}
