package com.example.demo.mapper;

import com.example.demo.dto.WorkflowDTO;
import com.example.demo.model.Workflow;
import org.springframework.stereotype.Component;

@Component
public class WorkflowMapper {

    public WorkflowDTO toDTO(Workflow workflow) {
        if (workflow == null) {
            return null;
        }

        WorkflowDTO dto = new WorkflowDTO();
        dto.setId(workflow.getWorkflowId());
        dto.setName(workflow.getWorkflowName());
        dto.setDescription(workflow.getDescription());
        // Map other fields as necessary

        return dto;
    }

    public Workflow toEntity(WorkflowDTO dto) {
        if (dto == null) {
            return null;
        }

        Workflow workflow = new Workflow();
        workflow.setWorkflowId(dto.getId());
        workflow.setWorkflowName(dto.getName());
        workflow.setDescription(dto.getDescription());
        // Map other fields as necessary

        return workflow;
    }
}
