package com.example.demo.controller;

import com.example.demo.dto.WorkflowProcessDTO;
import com.example.demo.model.WorkflowProcess;
import com.example.demo.service.WorkflowProcessService;
import com.example.demo.mapper.WorkflowProcessMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workflow-processes")
@Tag(name = "Workflow Process Management", description = "APIs for retrieving workflow-process relationships")
public class WorkflowProcessController {

    private static final Logger logger = LoggerFactory.getLogger(WorkflowProcessController.class);
    private final WorkflowProcessService workflowProcessService;
    private final WorkflowProcessMapper workflowProcessMapper;

    public WorkflowProcessController(WorkflowProcessService workflowProcessService, WorkflowProcessMapper workflowProcessMapper) {
        this.workflowProcessService = workflowProcessService;
        this.workflowProcessMapper = workflowProcessMapper;
    }

    @GetMapping
    @Operation(summary = "Retrieve all workflow-process mappings", description = "Fetches a list of all workflow-process mappings.")
    public ResponseEntity<List<WorkflowProcessDTO>> getAllWorkflowProcesses() {
        logger.info("Fetching all workflow-process mappings");
        List<WorkflowProcess> workflowProcesses = workflowProcessService.getAllWorkflowProcesses();
        List<WorkflowProcessDTO> workflowProcessDTOs = workflowProcessMapper.toDtoList(workflowProcesses);
        return ResponseEntity.ok(workflowProcessDTOs);
    }

    @GetMapping("/workflow/{workflowId}")
    @Operation(summary = "Retrieve all processes for a given workflow", description = "Fetches all processes assigned to a specific workflow.")
    public ResponseEntity<List<WorkflowProcessDTO>> getProcessesByWorkflow(
            @Parameter(description = "The ID of the workflow", required = true) @PathVariable Long workflowId) {
        logger.info("Fetching processes for workflow with ID: {}", workflowId);
        List<WorkflowProcess> workflowProcesses = workflowProcessService.getProcessesByWorkflow(workflowId);
        List<WorkflowProcessDTO> workflowProcessDTOs = workflowProcessMapper.toDtoList(workflowProcesses);
        return ResponseEntity.ok(workflowProcessDTOs);
    }

    @GetMapping("/process/{processId}")
    @Operation(summary = "Retrieve all workflows for a given process", description = "Fetches all workflows assigned to a specific process.")
    public ResponseEntity<List<WorkflowProcessDTO>> getWorkflowsByProcess(
            @Parameter(description = "The ID of the process", required = true) @PathVariable Long processId) {
        logger.info("Fetching workflows for process with ID: {}", processId);
        List<WorkflowProcess> workflowProcesses = workflowProcessService.getWorkflowsByProcess(processId);
        List<WorkflowProcessDTO> workflowProcessDTOs = workflowProcessMapper.toDtoList(workflowProcesses);
        return ResponseEntity.ok(workflowProcessDTOs);
    }
}
