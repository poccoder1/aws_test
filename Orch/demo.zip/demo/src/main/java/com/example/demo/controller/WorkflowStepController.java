package com.example.demo.controller;

import com.example.demo.dto.WorkflowStepDTO;
import com.example.demo.mapper.WorkflowStepMapper;
import com.example.demo.model.WorkflowStep;
import com.example.demo.service.WorkflowStepService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workflow-steps")
@Tag(name = "Workflow Step Management", description = "APIs for managing workflow steps")
public class WorkflowStepController {

    private static final Logger logger = LoggerFactory.getLogger(WorkflowStepController.class);
    private final WorkflowStepService workflowStepService;
    private final WorkflowStepMapper workflowStepMapper;

    public WorkflowStepController(WorkflowStepService workflowStepService, WorkflowStepMapper workflowStepMapper) {
        this.workflowStepService = workflowStepService;
        this.workflowStepMapper = workflowStepMapper;
    }

    @GetMapping
    @Operation(summary = "Retrieve all workflow steps", description = "Fetches a list of all workflow steps.")
    public ResponseEntity<List<WorkflowStepDTO>> getAllWorkflowSteps() {
        logger.info("Fetching all workflow steps");
        List<WorkflowStep> workflowSteps = workflowStepService.getAllWorkflowSteps();
        List<WorkflowStepDTO> workflowStepDTOs = workflowSteps.stream()
                .map(workflowStepMapper::toDTO)
                .toList(); // Assuming Java 11+
        return ResponseEntity.ok(workflowStepDTOs);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Retrieve a workflow step by ID", description = "Fetches the details of a workflow step by its ID.")
    public ResponseEntity<WorkflowStepDTO> getWorkflowStepById(
            @Parameter(description = "The ID of the workflow step", required = true)
            @PathVariable Long id) {
        logger.info("Fetching workflow step with ID: {}", id);
        WorkflowStep workflowStep = workflowStepService.getWorkflowStepById(id);
        if (workflowStep == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(workflowStepMapper.toDTO(workflowStep));
    }

    @PostMapping
    @Operation(summary = "Create a new workflow step", description = "Creates a new workflow step and returns it.")
    public ResponseEntity<WorkflowStepDTO> createWorkflowStep(
            @Parameter(description = "WorkflowStep object to be created", required = true)
            @RequestBody WorkflowStepDTO workflowStepDTO) {
        logger.info("Creating new workflow step: {}", workflowStepDTO);
        WorkflowStep createdWorkflowStep = workflowStepService.createWorkflowStep(workflowStepMapper.toEntity(workflowStepDTO));
        return ResponseEntity.ok(workflowStepMapper.toDTO(createdWorkflowStep));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing workflow step", description = "Updates an existing workflow step and returns the updated workflow step.")
    public ResponseEntity<WorkflowStepDTO> updateWorkflowStep(
            @Parameter(description = "The ID of the workflow step to be updated", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated workflow step object", required = true)
            @RequestBody WorkflowStepDTO workflowStepDTO) {
        logger.info("Updating workflow step with ID: {}", id);
        WorkflowStepDTO updatedWorkflowStepDTO = workflowStepService.updateWorkflowStep(id, workflowStepMapper.toEntity(workflowStepDTO));
        if (updatedWorkflowStepDTO == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedWorkflowStepDTO);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a workflow step", description = "Deletes a workflow step by its ID.")
    public ResponseEntity<Void> deleteWorkflowStep(
            @Parameter(description = "The ID of the workflow step to be deleted", required = true)
            @PathVariable Long id) {
        logger.info("Deleting workflow step with ID: {}", id);
        boolean isDeleted = workflowStepService.deleteWorkflowStep(id);
        if (isDeleted) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    // New endpoint to get WorkflowSteps by Workflow ID
    @GetMapping("/workflow/{workflowId}")
    @Operation(summary = "Retrieve workflow steps by Workflow ID", description = "Fetches a list of workflow steps for a given workflow ID.")
    public ResponseEntity<List<WorkflowStepDTO>> getWorkflowStepsByWorkflowId(
            @Parameter(description = "The ID of the workflow to retrieve steps for", required = true)
            @PathVariable Long workflowId) {
        logger.info("Fetching workflow steps for workflow ID: {}", workflowId);
        List<WorkflowStepDTO> workflowSteps = workflowStepService.getWorkflowStepsByWorkflowId(workflowId);
        return ResponseEntity.ok(workflowSteps);
    }
}
