package com.example.demo.controller;

import com.example.demo.dto.FileProcessStatusDTO;
import com.example.demo.service.FileProcessStatusService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/process-status")
@Tag(name = "File Process Status Management", description = "APIs for managing file process statuses")
public class FileProcessStatusController {

    private static final Logger logger = LoggerFactory.getLogger(FileProcessStatusController.class);
    private final FileProcessStatusService fileProcessStatusService;

    public FileProcessStatusController(FileProcessStatusService fileProcessStatusService) {
        this.fileProcessStatusService = fileProcessStatusService;
    }

    @GetMapping("/{processId}")
    @Operation(summary = "Get file process status by process ID", description = "Retrieve the file process status for a given process ID.")
    public ResponseEntity<List<FileProcessStatusDTO>> getFileProcessStatus(
            @Parameter(description = "The ID of the process", required = true)
            @PathVariable Long processId) {
        logger.info("Fetching file process status for process ID: {}", processId);
        List<FileProcessStatusDTO> statuses = fileProcessStatusService.getFileProcessStatusForProcess(processId);
        return ResponseEntity.ok(statuses);
    }
}
