package com.example.demo.repository;
import com.example.demo.model.FileTypeRelationship;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Set;

public interface FileTypeRelationshipRepository extends JpaRepository<FileTypeRelationship, Long> {

    // Corrected method to find relationships by Workflow Process ID
    List<FileTypeRelationship> findByWorkflowProcess_WorkflowProcessId(Long workflowProcessId);

    @Query("SELECT ftr FROM FileTypeRelationship ftr WHERE ftr.inputFileType = :inputFileType")
    List<FileTypeRelationship> findByInputFileType(@Param("inputFileType") String inputFileType);

    List<FileTypeRelationship> findByWorkflowProcess_WorkflowProcessIdIn(Set<Long> workflowProcessIds);

    @Query("SELECT ftr FROM FileTypeRelationship ftr " +
            "WHERE ftr.workflowProcess.workflowProcessId IN " +
            "(SELECT DISTINCT ftr2.workflowProcess.workflowProcessId " +
            " FROM FileTypeRelationship ftr2 " +
            " WHERE ftr2.inputFileType = :inputFileType)")
    List<FileTypeRelationship> findAllByInputFileTypeAndDistinctWorkflowProcessIds(@Param("inputFileType") String inputFileType);



}
