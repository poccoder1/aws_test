package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class WorkflowStep {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "workflow_step_id")
    private Long workflowStepId;

    @Column(name = "step_order")
    private Integer stepOrder;

    @Column(name = "service_name")
    private String serviceName;

    @Column(name = "step_description")
    private String stepDescription;

    @ManyToOne
    @JoinColumn(name = "workflow_id")
    private Workflow workflow;

//    @ManyToOne
//    @JoinColumn(name = "workflow_process_id")
//    private WorkflowProcess workflowProcess;

    public WorkflowStep() {}

    public WorkflowStep(Long workflowStepId, Workflow workflow, Integer stepOrder, String serviceName, String stepDescription) {
        this.workflowStepId = workflowStepId;
        this.workflow = workflow;
        this.stepOrder = stepOrder;
        this.serviceName = serviceName;
        this.stepDescription = stepDescription;
    }

    public WorkflowStep( Workflow workflow, Integer stepOrder, String serviceName, String stepDescription) {
        this.workflow = workflow;
        this.stepOrder = stepOrder;
        this.serviceName = serviceName;
        this.stepDescription = stepDescription;
    }
}
