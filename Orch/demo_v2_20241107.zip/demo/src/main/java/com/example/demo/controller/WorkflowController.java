package com.example.demo.controller;

import com.example.demo.dto.WorkflowDTO;
import com.example.demo.model.Workflow;
import com.example.demo.service.WorkflowService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/workflows")
@Tag(name = "Workflow Management", description = "APIs for managing workflows")
public class WorkflowController {

    private static final Logger logger = LoggerFactory.getLogger(WorkflowController.class);
    private final WorkflowService workflowService;

    public WorkflowController(WorkflowService workflowService) {
        this.workflowService = workflowService;
    }

    @GetMapping
    @Operation(summary = "Retrieve all workflows", description = "Fetches a list of all workflows.")
    public ResponseEntity<List<WorkflowDTO>> getAllWorkflows() {
        logger.info("Fetching all workflows");
        List<WorkflowDTO> workflows = workflowService.getAllWorkflowDTOs();
        return ResponseEntity.ok(workflows);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Retrieve a workflow by ID", description = "Fetches the details of a workflow by its ID.")
    public ResponseEntity<WorkflowDTO> getWorkflowById(
            @Parameter(description = "The ID of the workflow", required = true)
            @PathVariable Long id) {
        logger.info("Fetching workflow with ID: {}", id);
        WorkflowDTO workflowDTO = workflowService.getWorkflowDTOById(id);
        if (workflowDTO == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(workflowDTO);
    }

    @PostMapping
    @Operation(summary = "Create a new workflow", description = "Creates a new workflow and returns the created workflow.")
    public ResponseEntity<WorkflowDTO> createWorkflow(
            @Parameter(description = "Workflow object to be created", required = true)
            @RequestBody WorkflowDTO workflowDTO) {
        logger.info("Creating new workflow: {}", workflowDTO);
        WorkflowDTO workflow = workflowService.createWorkflow(workflowDTO);
        return ResponseEntity.ok(workflow);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing workflow", description = "Updates an existing workflow and returns the updated workflow.")
    public ResponseEntity<WorkflowDTO> updateWorkflow(
            @Parameter(description = "The ID of the workflow to be updated", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated workflow object", required = true)
            @RequestBody WorkflowDTO workflowDTO) {
        logger.info("Updating workflow with ID: {}", id);
        WorkflowDTO updatedWorkflowDTO = workflowService.updateWorkflow(id, workflowDTO);
        if (updatedWorkflowDTO == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedWorkflowDTO);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a workflow", description = "Deletes a workflow by its ID.")
    public ResponseEntity<Void> deleteWorkflow(
            @Parameter(description = "The ID of the workflow to be deleted", required = true)
            @PathVariable Long id) {
        logger.info("Deleting workflow with ID: {}", id);
        boolean isDeleted = workflowService.deleteWorkflow(id);
        if (isDeleted) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
