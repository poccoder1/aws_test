package com.example.demo.repository;

import com.example.demo.model.WorkflowProcess;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkflowProcessRepository extends JpaRepository<WorkflowProcess, Long> {

    List<WorkflowProcess> findByWorkflow_WorkflowId(Long workflowId);

    List<WorkflowProcess> findByProcess_ProcessId(Long processId);
}
