package com.example.demo.dto;

import java.time.LocalDate;
import java.util.List;

public class ServiceRequest {
    private String fileType;
    private String batchId;
    private String archiveId;
    private List<String> outputFileTypes;
    private LocalDate businessDate;
    private int version;

    // Constructor, Getters, and Setters

    public ServiceRequest(String fileType, String batchId, String archiveId,
                          List<String> outputFileTypes, LocalDate businessDate, int version) {
        this.fileType = fileType;
        this.batchId = batchId;
        this.archiveId = archiveId;
        this.outputFileTypes = outputFileTypes;
        this.businessDate = businessDate;
        this.version = version;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getArchiveId() {
        return archiveId;
    }

    public void setArchiveId(String archiveId) {
        this.archiveId = archiveId;
    }

    public List<String> getOutputFileTypes() {
        return outputFileTypes;
    }

    public void setOutputFileTypes(List<String> outputFileTypes) {
        this.outputFileTypes = outputFileTypes;
    }

    public LocalDate getBusinessDate() {
        return businessDate;
    }

    public void setBusinessDate(LocalDate businessDate) {
        this.businessDate = businessDate;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
}

