package com.example.demo.dto;

import lombok.Data;

@Data
public class FileTypeRelationshipResponseDTO {
    private String inputFileType;
    private String outputFileType;
    private Integer stepOrder;
    private String serviceName;
    private Long workflowProcessId;
    private String processName;
}
