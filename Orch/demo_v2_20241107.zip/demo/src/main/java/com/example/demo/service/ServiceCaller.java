package com.example.demo.service;

import com.example.demo.dto.ServiceRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ServiceCaller {

    private static final Logger logger = LoggerFactory.getLogger(ServiceCaller.class);

    public void callService(ServiceRequest request) {
        // Log the request details
        logger.info("Calling service with the following details:");
        logger.info("File Type: {}", request.getFileType());
        logger.info("Batch ID: {}", request.getBatchId());
        logger.info("Archive ID: {}", request.getArchiveId());
        logger.info("Output File Types: {}", request.getOutputFileTypes());
        logger.info("Business Date: {}", request.getBusinessDate());
        logger.info("Version: {}", request.getVersion());

        // Simulate calling the service based on file type
        try {
            if ("GFF".equals(request.getFileType())) {
                callGFFService(request);
            } else if ("GFD".equals(request.getFileType())) {
                callGFDService(request);
            } else {
                throw new UnsupportedOperationException("Service for file type " + request.getFileType() + " is not implemented.");
            }

            logger.info("Service call for {} completed successfully.", request.getFileType());

        } catch (Exception e) {
            logger.error("Error occurred while calling service for file type {}: {}", request.getFileType(), e.getMessage());
            throw e;
        }
    }

    private void callGFFService(ServiceRequest request) {
        // Simulate GFF service logic
        logger.info("Processing GFF service for archive ID: {}", request.getArchiveId());
        // Placeholder for actual GFF service interaction logic
    }

    private void callGFDService(ServiceRequest request) {
        // Simulate GFD service logic
        logger.info("Processing GFD service for archive ID: {}", request.getArchiveId());
        // Placeholder for actual GFD service interaction logic
    }
}

