package com.example.demo.service;

import com.example.demo.dto.FileTypeRelationshipResponseDTO;
import com.example.demo.model.WorkflowProcess;
import com.example.demo.model.WorkflowStep;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class OrchestrationService {

    private final FileTypeRelationshipService fileTypeRelationshipService;
    private final FileProcessStatusService fileProcessStatusService;
    private final ServiceCaller serviceCaller;

    public OrchestrationService(FileTypeRelationshipService fileTypeRelationshipService,
                                FileProcessStatusService fileProcessStatusService,
                                ServiceCaller serviceCaller) {
        this.fileTypeRelationshipService = fileTypeRelationshipService;
        this.fileProcessStatusService = fileProcessStatusService;
        this.serviceCaller = serviceCaller;
    }

    public void executeWorkflow(String inputFileType, UUID fileDownloadId, String batchId, LocalDate businessDate, int version) {
        List<FileTypeRelationshipResponseDTO> workflowSteps = fileTypeRelationshipService.getDetailsByInputFileType(inputFileType);

        Map<String, List<FileTypeRelationshipResponseDTO>> serviceGroups = workflowSteps.stream()
                .filter(step -> step.getStepOrder() > 0)
                .collect(Collectors.groupingBy(step -> step.getStepOrder() + "_" + step.getServiceName()));

        for (Map.Entry<String, List<FileTypeRelationshipResponseDTO>> entry : serviceGroups.entrySet()) {
            List<FileTypeRelationshipResponseDTO> stepsForService = entry.getValue();
            if (stepsForService.isEmpty()) {
                continue;
            }

            FileTypeRelationshipResponseDTO serviceStep = stepsForService.get(0);

            for (FileTypeRelationshipResponseDTO step : stepsForService) {
                fileProcessStatusService.saveFileProcessStatus(
                        fileDownloadId, batchId,
                        new WorkflowProcess(step.getWorkflowProcessId()),
                        step.getInputFileType(), "BEFORE_CALL",
                        new WorkflowStep(step.getStepOrder(), step.getWorkflowProcessId()),
                        businessDate, version, null);
            }

            try {
                serviceCaller.callService(serviceStep.getServiceName());

                for (FileTypeRelationshipResponseDTO step : stepsForService) {
                    fileProcessStatusService.saveFileProcessStatus(
                            fileDownloadId, batchId,
                            new WorkflowProcess(step.getWorkflowProcessId()),
                            step.getInputFileType(), "AFTER_CALL",
                            new WorkflowStep(step.getStepOrder(), step.getWorkflowProcessId()),
                            businessDate, version, null);
                }
            } catch (Exception e) {
                for (FileTypeRelationshipResponseDTO step : stepsForService) {
                    fileProcessStatusService.saveFileProcessStatus(
                            fileDownloadId, batchId,
                            new WorkflowProcess(step.getWorkflowProcessId()),
                            step.getInputFileType(), "ERROR",
                            new WorkflowStep(step.getStepOrder(), step.getWorkflowProcessId()),
                            businessDate, version, e.getMessage());
                }
            }
        }
    }
}

