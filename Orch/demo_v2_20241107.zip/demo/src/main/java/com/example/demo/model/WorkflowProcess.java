package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class WorkflowProcess {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "workflow_process_id")
    private Long workflowProcessId;

    @ManyToOne
    @JoinColumn(name = "workflow_id")
    private Workflow workflow;

    @ManyToOne
    @JoinColumn(name = "process_id")
    private Process process;

    @OneToMany(mappedBy = "workflowProcess", cascade = CascadeType.REMOVE)
    private List<FileTypeRelationship> fileTypeRelationships;

    public WorkflowProcess() {}

    public WorkflowProcess(Long workflowProcessId, Workflow workflow, Process process) {
        this.workflowProcessId = workflowProcessId;
        this.workflow = workflow;
        this.process = process;
    }

    public WorkflowProcess(Workflow workflow, Process process) {
        this.workflow = workflow;
        this.process = process;
    }
}
