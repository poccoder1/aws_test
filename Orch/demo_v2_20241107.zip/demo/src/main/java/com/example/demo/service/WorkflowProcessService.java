package com.example.demo.service;

import com.example.demo.model.WorkflowProcess;
import com.example.demo.repository.WorkflowProcessRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkflowProcessService {

    private static final Logger logger = LoggerFactory.getLogger(WorkflowProcessService.class);
    private final WorkflowProcessRepository workflowProcessRepository;

    public WorkflowProcessService(WorkflowProcessRepository workflowProcessRepository) {
        this.workflowProcessRepository = workflowProcessRepository;
    }

    public List<WorkflowProcess> getAllWorkflowProcesses() {
        logger.info("Retrieving all workflow-process mappings");
        return workflowProcessRepository.findAll();
    }

    public List<WorkflowProcess> getProcessesByWorkflow(Long workflowId) {
        logger.info("Fetching processes for workflow ID: {}", workflowId);
        return workflowProcessRepository.findByWorkflow_WorkflowId(workflowId);
    }

    public List<WorkflowProcess> getWorkflowsByProcess(Long processId) {
        logger.info("Fetching workflows for process ID: {}", processId);
        return workflowProcessRepository.findByProcess_ProcessId(processId);
    }
}
