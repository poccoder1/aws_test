package com.example.demo.repository;
import com.example.demo.model.Workflow;
import com.example.demo.model.WorkflowStep;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public interface WorkflowStepRepository extends JpaRepository<WorkflowStep, Long> {
    Optional<WorkflowStep> findByWorkflowAndStepOrder(Workflow workflow, int stepOrder);
    List<WorkflowStep> findByWorkflow_WorkflowId(Long workflowId);
    List<WorkflowStep> findByWorkflow_WorkflowIdAndStepOrder(Long workflowId, int stepOrder);

    @Query("SELECT ws FROM WorkflowStep ws WHERE ws.workflow.workflowId IN :workflowIds AND ws.stepOrder IN :stepOrders")
    List<WorkflowStep> findByWorkflow_WorkflowIdInAndStepOrderIn(
            @Param("workflowIds") Set<Long> workflowIds, @Param("stepOrders") Set<Integer> stepOrders);

    // List<WorkflowStep> findByWorkflowProcess_WorkflowProcessId(Long workflowProcessId);
}
