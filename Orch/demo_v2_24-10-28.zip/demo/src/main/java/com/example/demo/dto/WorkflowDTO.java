package com.example.demo.dto;

public class WorkflowDTO {
    private Long id;
    private String name; // Assuming the Workflow has a name
    private String description; // Add more fields as needed

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
