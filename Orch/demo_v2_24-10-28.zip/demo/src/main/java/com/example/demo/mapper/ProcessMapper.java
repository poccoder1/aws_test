package com.example.demo.mapper;

import com.example.demo.dto.ProcessDTO;
import com.example.demo.model.Process;
import org.springframework.stereotype.Component;

@Component
public class ProcessMapper {

    public ProcessDTO toDto(Process process) {
        ProcessDTO dto = new ProcessDTO();
        dto.setProcessId(process.getProcessId());
        dto.setProcessName(process.getProcessName());
        dto.setDescription(process.getDescription());
        return dto;
    }

    public Process toEntity(ProcessDTO dto) {
        Process process = new Process();
        process.setProcessId(dto.getProcessId());
        process.setProcessName(dto.getProcessName());
        process.setDescription(dto.getDescription());
        return process;
    }
}
