package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Process {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "process_id")
    private Long processId;

    @Column(name = "process_name")
    private String processName;

    @Column(name = "description")
    private String description;

    public Process() {}

    public Process(Long processId, String processName, String description) {
        this.processId = processId;
        this.processName = processName;
        this.description = description;
    }

    public Process(String processName, String description) {
        this.processName = processName;
        this.description = description;
    }
}
