package com.example.demo.controller;

import com.example.demo.dto.FileTypeRelationshipDTO;
import com.example.demo.dto.FileTypeRelationshipResponseDTO;
import com.example.demo.mapper.FileTypeRelationshipMapper;
import com.example.demo.model.FileTypeRelationship;
import com.example.demo.service.FileTypeRelationshipService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/file-type-relationships")
@Tag(name = "File Type Relationship Management", description = "APIs for managing file type relationships")
public class FileTypeRelationshipController {

    private static final Logger logger = LoggerFactory.getLogger(FileTypeRelationshipController.class);
    private final FileTypeRelationshipService fileTypeRelationshipService;
    private final FileTypeRelationshipMapper fileTypeRelationshipMapper;

    public FileTypeRelationshipController(FileTypeRelationshipService fileTypeRelationshipService,
                                          FileTypeRelationshipMapper fileTypeRelationshipMapper) {
        this.fileTypeRelationshipService = fileTypeRelationshipService;
        this.fileTypeRelationshipMapper = fileTypeRelationshipMapper;
    }

    @GetMapping
    @Operation(summary = "Retrieve all file type relationships", description = "Fetches a list of all file type relationships.")
    public ResponseEntity<List<FileTypeRelationshipDTO>> getAllFileTypeRelationships() {
        logger.info("Fetching all file type relationships");
        List<FileTypeRelationshipDTO> relationships = fileTypeRelationshipService.getAllFileTypeRelationships()
                .stream()
                .map(fileTypeRelationshipMapper::toDTO)
                .toList();
        return ResponseEntity.ok(relationships);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Retrieve a file type relationship by ID", description = "Fetches a file type relationship by its ID.")
    public ResponseEntity<FileTypeRelationshipDTO> getFileTypeRelationshipById(
            @Parameter(description = "The ID of the file type relationship", required = true)
            @PathVariable Long id) {
        logger.info("Fetching file type relationship with ID: {}", id);
        FileTypeRelationship relationship = fileTypeRelationshipService.getFileTypeRelationshipById(id);
        if (relationship == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(fileTypeRelationshipMapper.toDTO(relationship));
    }

    @GetMapping("/workflow/{workflowProcessId}")
    @Operation(summary = "Retrieve file type relationships by workflow process ID", description = "Fetches all file type relationships by a specific workflow process ID.")
    public ResponseEntity<List<FileTypeRelationshipDTO>> getFileTypeRelationshipsByWorkflowProcessId(
            @Parameter(description = "The ID of the workflow process", required = true)
            @PathVariable Long workflowProcessId) {
        logger.info("Fetching file type relationships for workflow process ID: {}", workflowProcessId);
        List<FileTypeRelationshipDTO> relationships = fileTypeRelationshipService.getFileTypeRelationshipsByWorkflowProcessId(workflowProcessId)
                .stream()
                .map(fileTypeRelationshipMapper::toDTO)
                .toList();
        return ResponseEntity.ok(relationships);
    }

    @PostMapping
    @Operation(summary = "Create a new file type relationship", description = "Creates a new file type relationship and returns it.")
    public ResponseEntity<FileTypeRelationshipDTO> createFileTypeRelationship(
            @Parameter(description = "FileTypeRelationship object to be created", required = true)
            @RequestBody FileTypeRelationshipDTO fileTypeRelationshipDTO) {
        logger.info("Creating new file type relationship: {}", fileTypeRelationshipDTO);
        FileTypeRelationship fileTypeRelationship = fileTypeRelationshipMapper.toEntity(fileTypeRelationshipDTO);
        FileTypeRelationship createdFileTypeRelationship = fileTypeRelationshipService.createFileTypeRelationship(fileTypeRelationship);
        return ResponseEntity.ok(fileTypeRelationshipMapper.toDTO(createdFileTypeRelationship));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing file type relationship", description = "Updates an existing file type relationship and returns the updated relationship.")
    public ResponseEntity<FileTypeRelationshipDTO> updateFileTypeRelationship(
            @Parameter(description = "The ID of the file type relationship to be updated", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated file type relationship object", required = true)
            @RequestBody FileTypeRelationshipDTO fileTypeRelationshipDTO) {
        logger.info("Updating file type relationship with ID: {}", id);
        FileTypeRelationship updatedFileTypeRelationship = fileTypeRelationshipService.updateFileTypeRelationship(id, fileTypeRelationshipDTO);
        if (updatedFileTypeRelationship == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(fileTypeRelationshipMapper.toDTO(updatedFileTypeRelationship));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a file type relationship", description = "Deletes a file type relationship by its ID.")
    public ResponseEntity<Void> deleteFileTypeRelationship(
            @Parameter(description = "The ID of the file type relationship to be deleted", required = true)
            @PathVariable Long id) {
        logger.info("Deleting file type relationship with ID: {}", id);
        boolean isDeleted = fileTypeRelationshipService.deleteFileTypeRelationship(id);
        if (isDeleted) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }


    @GetMapping("/details/{inputFileType}")
    public ResponseEntity<List<FileTypeRelationshipResponseDTO>> getDetailsByInputFileType(@PathVariable String inputFileType) {
        logger.info("Received request to fetch details by input file type: {}", inputFileType);
        List<FileTypeRelationshipResponseDTO> response = fileTypeRelationshipService.getDetailsByInputFileType(inputFileType);

        if (response.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(response);
    }

}
