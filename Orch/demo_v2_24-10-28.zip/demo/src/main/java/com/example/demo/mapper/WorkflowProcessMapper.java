package com.example.demo.mapper;

import com.example.demo.dto.WorkflowProcessDTO;
import com.example.demo.model.WorkflowProcess;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class WorkflowProcessMapper {

    public WorkflowProcessDTO toDto(WorkflowProcess workflowProcess) {
        if (workflowProcess == null) {
            return null;
        }
        WorkflowProcessDTO dto = new WorkflowProcessDTO();
        dto.setWorkflowProcessId(workflowProcess.getWorkflowProcessId());
        dto.setWorkflowId(workflowProcess.getWorkflow().getWorkflowId());
        dto.setProcessId(workflowProcess.getProcess().getProcessId());
        return dto;
    }

    public List<WorkflowProcessDTO> toDtoList(List<WorkflowProcess> workflowProcesses) {
        return workflowProcesses.stream().map(this::toDto).collect(Collectors.toList());
    }
}
