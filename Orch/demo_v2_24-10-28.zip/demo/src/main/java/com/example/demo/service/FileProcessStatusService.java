package com.example.demo.service;

import com.example.demo.dto.FileProcessStatusDTO;
import com.example.demo.mapper.FileProcessStatusMapper;
import com.example.demo.model.FileProcessStatus;
import com.example.demo.repository.FileProcessStatusRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FileProcessStatusService {

    private static final Logger logger = LoggerFactory.getLogger(FileProcessStatusService.class);
    private final FileProcessStatusRepository fileProcessStatusRepository;
    private final FileProcessStatusMapper fileProcessStatusMapper;

    public FileProcessStatusService(FileProcessStatusRepository fileProcessStatusRepository,
                                    FileProcessStatusMapper fileProcessStatusMapper) {
        this.fileProcessStatusRepository = fileProcessStatusRepository;
        this.fileProcessStatusMapper = fileProcessStatusMapper;
    }

    public List<FileProcessStatusDTO> getFileProcessStatusForProcess(Long processId) {
        logger.info("Retrieving file process status for process ID: {}", processId);
        List<FileProcessStatus> statuses = fileProcessStatusRepository.findByWorkflowProcessProcessProcessId(processId);
        return statuses.stream()
                .map(fileProcessStatusMapper::toDTO)
                .collect(Collectors.toList());
    }
}
