package com.example.demo.mapper;

import com.example.demo.dto.WorkflowStepDTO;
import com.example.demo.model.Workflow;
import com.example.demo.model.WorkflowStep;
import com.example.demo.repository.WorkflowRepository;
import org.springframework.stereotype.Component;

@Component
public class WorkflowStepMapper {

    private final WorkflowRepository workflowRepository;

    public WorkflowStepMapper(WorkflowRepository workflowRepository) {
        this.workflowRepository = workflowRepository;
    }

    public WorkflowStepDTO toDTO(WorkflowStep workflowStep) {
        WorkflowStepDTO dto = new WorkflowStepDTO();
        dto.setWorkflowStepId(workflowStep.getWorkflowStepId());
        dto.setServiceName(workflowStep.getServiceName());
        dto.setStepDescription(workflowStep.getStepDescription());
        dto.setStepOrder(workflowStep.getStepOrder());
        dto.setWorkflowId(workflowStep.getWorkflow().getWorkflowId());



        // Map other fields as necessary
        return dto;
    }

    public WorkflowStep toEntity(WorkflowStepDTO dto) {
        WorkflowStep workflowStep = new WorkflowStep();
        workflowStep.setServiceName(dto.getServiceName());
        workflowStep.setStepDescription(dto.getStepDescription());
        workflowStep.setStepOrder(dto.getStepOrder());

        // Retrieve the Workflow object from the repository and set it
        if (dto.getWorkflowId() != null) {
            Workflow workflow = workflowRepository.findById(dto.getWorkflowId())
                    .orElseThrow(() -> new IllegalArgumentException("Workflow with ID " + dto.getWorkflowId() + " does not exist"));
            workflowStep.setWorkflow(workflow);
        }
        // Map other fields as necessary
        return workflowStep;
    }
}
