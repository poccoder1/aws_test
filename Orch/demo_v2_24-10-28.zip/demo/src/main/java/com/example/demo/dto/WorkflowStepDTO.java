package com.example.demo.dto;

import lombok.Data;

@Data
public class WorkflowStepDTO {
    private Long workflowStepId;
    private String serviceName;
    private Integer stepOrder;
    private String stepDescription;
    private Long workflowId;

}
