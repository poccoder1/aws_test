# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/3.3.5/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.3.5/maven-plugin/build-image.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/3.3.5/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Spring Web](https://docs.spring.io/spring-boot/3.3.5/reference/web/servlet.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

### usefull links
http://localhost:8080/swagger-ui/index.html
Swagger UI: http://localhost:8080/swagger-ui.html
OpenAPI JSON (optional): http://localhost:8080/v3/api-docs

run below query::
SELECT * FROM WORKFLOW;
SELECT * FROM PROCESS ;
SELECT * FROM WORKFLOW_PROCESS ;
SELECT * FROM WORKFLOW_STEP ;
SELECT * FROM FILE_TYPE_RELATIONSHIP ;

SELECT
W.WORKFLOW_ID,
W.WORKFLOW_NAME,
P.PROCESS_ID,
P.PROCESS_NAME,
WS.WORKFLOW_STEP_ID,
WS.STEP_ORDER,
WS.SERVICE_NAME,
WS.STEP_DESCRIPTION,
FTR.INPUT_FILE_TYPE,
FTR_OUTPUT.OUTPUT_FILE_TYPE
FROM
FILE_TYPE_RELATIONSHIP FTR
JOIN
WORKFLOW_PROCESS  WP ON FTR.WORKFLOW_PROCESS_ID = WP.WORKFLOW_PROCESS_ID
JOIN
WORKFLOW W ON WP.WORKFLOW_ID = W.WORKFLOW_ID
JOIN
PROCESS P ON WP.PROCESS_ID = P.PROCESS_ID
JOIN
WORKFLOW_STEP WS ON W.WORKFLOW_ID = WS.WORKFLOW_ID
LEFT JOIN
FILE_TYPE_RELATIONSHIP FTR_OUTPUT ON WS.STEP_ORDER = FTR_OUTPUT.STEP_ORDER
AND WP.WORKFLOW_PROCESS_ID = FTR_OUTPUT.WORKFLOW_PROCESS_ID
WHERE
FTR.INPUT_FILE_TYPE = 'EUREX_INPUT_00RPTCB012JPDFR_CSV_ZIP'
ORDER BY
W.WORKFLOW_ID, P.PROCESS_ID, WS.STEP_ORDER;

SELECT fps.*
FROM file_process_status fps
JOIN workflow_process wp ON fps.workflow_process_id = wp.id  -- Assuming 'id' is the primary key of 'workflow_process'
JOIN process p ON wp.process_id = p.id
WHERE p.id = 1;
