package com.example.demo.controller;

import com.example.demo.dto.ProcessDTO;
import com.example.demo.service.ProcessService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/processes")
@Tag(name = "Process Management", description = "APIs for managing processes")
public class ProcessController {

    private static final Logger logger = LoggerFactory.getLogger(ProcessController.class);
    private final ProcessService processService;

    public ProcessController(ProcessService processService) {
        this.processService = processService;
    }

    @GetMapping
    @Operation(summary = "Retrieve all processes", description = "Fetches a list of all processes.")
    public ResponseEntity<List<ProcessDTO>> getAllProcesses() {
        logger.info("Fetching all processes");
        List<ProcessDTO> processes = processService.getAllProcesses();
        return ResponseEntity.ok(processes);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Retrieve a process by ID", description = "Fetches the details of a process by its ID.")
    public ResponseEntity<ProcessDTO> getProcessById(
            @Parameter(description = "The ID of the process", required = true)
            @PathVariable Long id) {
        logger.info("Fetching process with ID: {}", id);
        ProcessDTO processDTO = processService.getProcessById(id);
        if (processDTO == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(processDTO);
    }

    @PostMapping
    @Operation(summary = "Create a new process", description = "Creates a new process and returns the created process.")
    public ResponseEntity<ProcessDTO> createProcess(
            @Parameter(description = "Process object to be created", required = true)
            @RequestBody ProcessDTO processDTO) {
        logger.info("Creating new process: {}", processDTO);
        ProcessDTO createdProcess = processService.createProcess(processDTO);
        return ResponseEntity.ok(createdProcess);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing process", description = "Updates an existing process and returns the updated process.")
    public ResponseEntity<ProcessDTO> updateProcess(
            @Parameter(description = "The ID of the process to be updated", required = true)
            @PathVariable Long id,
            @Parameter(description = "Updated process object", required = true)
            @RequestBody ProcessDTO processDTO) {
        logger.info("Updating process with ID: {}", id);
        ProcessDTO updatedProcessDTO = processService.updateProcess(id, processDTO);
        if (updatedProcessDTO == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updatedProcessDTO);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a process", description = "Deletes a process by its ID.")
    public ResponseEntity<Void> deleteProcess(
            @Parameter(description = "The ID of the process to be deleted", required = true)
            @PathVariable Long id) {
        logger.info("Deleting process with ID: {}", id);
        boolean isDeleted = processService.deleteProcess(id);
        if (isDeleted) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
