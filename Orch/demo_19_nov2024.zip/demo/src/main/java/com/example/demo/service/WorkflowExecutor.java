package com.example.demo.service;

import java.util.List;

public class WorkflowExecutor {

    private final ServiceCaller serviceCaller;
    private final FileProcessStatusService fileProcessStatusService;

    public WorkflowExecutor(ServiceCaller serviceCaller, FileProcessStatusService fileProcessStatusService) {
        this.serviceCaller = serviceCaller;
        this.fileProcessStatusService = fileProcessStatusService;
    }

    /**
     * Executes a single service task.
     */
    public boolean executeTask(ServiceTask task) {
        try {
            // Create and populate service request
            ServiceRequest serviceRequest = new ServiceRequest();
            populateServiceRequest(serviceRequest, task.context);

            // Log before service call
            logBeforeCall(task);

            // Call the service
            Object responseObject = serviceCaller.callService(serviceRequest);

            // Update context and log success
            updateContextWithResponse(task.context, responseObject);
            logAfterCall(task);

            return true; // Service call succeeded
        } catch (Exception e) {
            // Log error
            logError(task, e.getMessage());
            return false; // Service call failed
        }
    }

    private void logBeforeCall(ServiceTask task) {
        task.steps.forEach(step -> fileProcessStatusService.saveFileProcessStatus(
                task.fileDownloadId, task.batchId, task.workflowProcess, task.serviceStep.getInputFileType(),
                "BEFORE_CALL", step, task.businessDate, task.version, null));
        System.out.println("Before calling service: " + task.serviceStep.getServiceName());
    }

    private void logAfterCall(ServiceTask task) {
        task.steps.forEach(step -> fileProcessStatusService.saveFileProcessStatus(
                task.fileDownloadId, task.batchId, task.workflowProcess, task.serviceStep.getInputFileType(),
                "AFTER_CALL", step, task.businessDate, task.version, null));
        System.out.println("Service call succeeded: " + task.serviceStep.getServiceName());
    }

    private void logError(ServiceTask task, String errorMessage) {
        task.steps.forEach(step -> fileProcessStatusService.saveFileProcessStatus(
                task.fileDownloadId, task.batchId, task.workflowProcess, task.serviceStep.getInputFileType(),
                "ERROR", step, task.businessDate, task.version, errorMessage));
        System.err.println("Service call failed: " + task.serviceStep.getServiceName() + " | Error: " + errorMessage);
    }

    private void populateServiceRequest(ServiceRequest serviceRequest, Map<String, Object> context) {
        if (context.containsKey("previousResponseData")) {
            serviceRequest.setSomeParameter(context.get("previousResponseData"));
        }
    }

    private void updateContextWithResponse(Map<String, Object> context, Object responseObject) {
        if (responseObject instanceof YourResponseType) {
            YourResponseType response = (YourResponseType) responseObject;
            context.put("previousResponseData", response.getRequiredField());
        }
    }
}

