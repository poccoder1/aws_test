package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class FileTypeRelationship {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ft_relation_id")
    private Long ftRelationId;

    @Column(name = "input_file_type")
    private String inputFileType;

    @Column(name = "output_file_type")
    private String outputFileType;

    @Column(name = "step_order")
    private Integer stepOrder;

    @ManyToOne
    @JoinColumn(name = "workflow_process_id")
    private WorkflowProcess workflowProcess;

    public FileTypeRelationship() {}

    public FileTypeRelationship(Long ftRelationId, WorkflowProcess workflowProcess, String inputFileType,
                                String outputFileType, Integer stepOrder) {
        this.ftRelationId = ftRelationId;
        this.workflowProcess = workflowProcess;
        this.inputFileType = inputFileType;
        this.outputFileType = outputFileType;
        this.stepOrder = stepOrder;
    }

    public FileTypeRelationship(WorkflowProcess workflowProcess, String inputFileType,
                                String outputFileType, Integer stepOrder) {
        this.workflowProcess = workflowProcess;
        this.inputFileType = inputFileType;
        this.outputFileType = outputFileType;
        this.stepOrder = stepOrder;
    }
}
