package com.example.demo.service;

import com.example.demo.dto.FileTypeRelationshipResponseDTO;
import com.example.demo.dto.ServiceRequest;
import com.example.demo.dto.ServiceTask;
import com.example.demo.model.WorkflowProcess;
import com.example.demo.model.WorkflowStep;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.concurrent.*;
//
//public class OrchestrationService {
//
//    private final FileTypeRelationshipService fileTypeRelationshipService;
//    private final FileProcessStatusService fileProcessStatusService;
//    private final ServiceCaller serviceCaller;
//
//    private final ScheduledExecutorService retryExecutor = Executors.newScheduledThreadPool(10);
//    private final Map<String, BlockingQueue<ServiceTask>> retryQueues = new ConcurrentHashMap<>();
//
//    public OrchestrationService(FileTypeRelationshipService fileTypeRelationshipService,
//                                FileProcessStatusService fileProcessStatusService,
//                                ServiceCaller serviceCaller) {
//        this.fileTypeRelationshipService = fileTypeRelationshipService;
//        this.fileProcessStatusService = fileProcessStatusService;
//        this.serviceCaller = serviceCaller;
//    }
//
//    public void executeWorkflow(String inputFileType, UUID fileDownloadId, String batchId, LocalDate businessDate, int version) {
//        List<FileTypeRelationshipResponseDTO> workflowSteps = fileTypeRelationshipService.getDetailsByInputFileType(inputFileType);
//
//        Map<Integer, List<FileTypeRelationshipResponseDTO>> stepsByOrder = workflowSteps.stream()
//                .filter(step -> step.getStepOrder() > 0)
//                .collect(Collectors.groupingBy(FileTypeRelationshipResponseDTO::getStepOrder));
//
//        // Initialize retry queue for this workflow
//        String workflowId = UUID.randomUUID().toString();
//        retryQueues.put(workflowId, new LinkedBlockingQueue<>());
//
//        try {
//            for (Integer stepOrder : stepsByOrder.keySet().stream().sorted().collect(Collectors.toList())) {
//                List<FileTypeRelationshipResponseDTO> stepsForService = stepsByOrder.get(stepOrder);
//                if (stepsForService.isEmpty()) {
//                    continue;
//                }
//
//                FileTypeRelationshipResponseDTO serviceStep = stepsForService.get(0);
//                WorkflowProcess workflowProcess = fileTypeRelationshipService.getWorkflowProcessById(serviceStep.getWorkflowProcessId());
//                List<WorkflowStep> workflowStepsForSave = stepsForService.stream()
//                        .map(step -> fileTypeRelationshipService.getWorkflowStepById(step.getStepOrder(), step.getWorkflowProcessId()))
//                        .collect(Collectors.toList());
//
//                // Save BEFORE_CALL status
//                for (WorkflowStep step : workflowStepsForSave) {
//                    fileProcessStatusService.saveFileProcessStatus(
//                            fileDownloadId, batchId, workflowProcess, serviceStep.getInputFileType(),
//                            "BEFORE_CALL", step, businessDate, version, null);
//                }
//
//                ServiceTask task = new ServiceTask(serviceStep, workflowProcess, workflowStepsForSave,
//                        fileDownloadId, batchId, businessDate, version, workflowId);
//                executeServiceTask(task);
//            }
//        } finally {
//            retryQueues.remove(workflowId);
//        }
//    }
//
//    private void executeServiceTask(ServiceTask task) {
//        try {
//            // Create and call the service request
//            ServiceRequest serviceRequest = new ServiceRequest();
//            populateServiceRequest(serviceRequest, task.context);
//            Object responseObject = serviceCaller.callService(serviceRequest);
//
//            // Process response and mark as success
//            updateContextWithResponse(task.context, responseObject);
//            for (WorkflowStep step : task.steps) {
//                fileProcessStatusService.saveFileProcessStatus(
//                        task.fileDownloadId, task.batchId, task.workflowProcess,
//                        task.serviceStep.getInputFileType(), "AFTER_CALL", step,
//                        task.businessDate, task.version, null);
//            }
//        } catch (Exception e) {
//            // Log failure and schedule retry
//            for (WorkflowStep step : task.steps) {
//                fileProcessStatusService.saveFileProcessStatus(
//                        task.fileDownloadId, task.batchId, task.workflowProcess,
//                        task.serviceStep.getInputFileType(), "ERROR", step,
//                        task.businessDate, task.version, e.getMessage());
//            }
//            scheduleRetry(task);
//        }
//    }
//
//    private void scheduleRetry(ServiceTask task) {
//        BlockingQueue<ServiceTask> retryQueue = retryQueues.get(task.workflowId);
//        if (retryQueue != null) {
//            retryQueue.offer(task);
//            retryExecutor.schedule(() -> retryServiceTask(task), 10, TimeUnit.MINUTES);
//        }
//    }
//
//    private void retryServiceTask(ServiceTask task) {
//        BlockingQueue<ServiceTask> retryQueue = retryQueues.get(task.workflowId);
//        if (retryQueue != null && retryQueue.contains(task)) {
//            retryQueue.remove(task);
//            executeServiceTask(task);
//        }
//    }
//
//    private void populateServiceRequest(ServiceRequest serviceRequest, Map<String, Object> context) {
//        if (context.containsKey("previousResponseData")) {
//            serviceRequest.setSomeParameter(context.get("previousResponseData"));
//        }
//    }
//
//    private void updateContextWithResponse(Map<String, Object> context, Object responseObject) {
//        if (responseObject instanceof YourResponseType) {
//            YourResponseType response = (YourResponseType) responseObject;
//            context.put("previousResponseData", response.getRequiredField());
//        }
//    }
//
//    private static class ServiceTask {
//        final FileTypeRelationshipResponseDTO serviceStep;
//        final WorkflowProcess workflowProcess;
//        final List<WorkflowStep> steps;
//        final UUID fileDownloadId;
//        final String batchId;
//        final LocalDate businessDate;
//        final int version;
//        final String workflowId;
//        final Map<String, Object> context = new ConcurrentHashMap<>();
//
//        ServiceTask(FileTypeRelationshipResponseDTO serviceStep, WorkflowProcess workflowProcess,
//                    List<WorkflowStep> steps, UUID fileDownloadId, String batchId,
//                    LocalDate businessDate, int version, String workflowId) {
//            this.serviceStep = serviceStep;
//            this.workflowProcess = workflowProcess;
//            this.steps = steps;
//            this.fileDownloadId = fileDownloadId;
//            this.batchId = batchId;
//            this.businessDate = businessDate;
//            this.version = version;
//            this.workflowId = workflowId;
//        }
//    }
//}


import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class OrchestrationService {

    private final FileTypeRelationshipService fileTypeRelationshipService;
    private final FileProcessStatusService fileProcessStatusService;
    private final ServiceCaller serviceCaller;
    private final RetryManager retryManager;

    public OrchestrationService(FileTypeRelationshipService fileTypeRelationshipService,
                                FileProcessStatusService fileProcessStatusService,
                                ServiceCaller serviceCaller) {
        this.fileTypeRelationshipService = fileTypeRelationshipService;
        this.fileProcessStatusService = fileProcessStatusService;
        this.serviceCaller = serviceCaller;
        this.retryManager = new RetryManager(serviceCaller, fileProcessStatusService);
    }

    /**
     * Executes the workflow for a given input file type.
     */
    public void executeWorkflow(String inputFileType, UUID fileDownloadId, String batchId, LocalDate businessDate, int version) {
        List<FileTypeRelationshipResponseDTO> workflowSteps = fileTypeRelationshipService.getDetailsByInputFileType(inputFileType);

        // Group steps by order to maintain execution sequence
        Map<Integer, List<FileTypeRelationshipResponseDTO>> stepsByOrder = workflowSteps.stream()
                .filter(step -> step.getStepOrder() > 0)
                .collect(Collectors.groupingBy(FileTypeRelationshipResponseDTO::getStepOrder));

        String workflowId = UUID.randomUUID().toString();
        try {
            for (Integer stepOrder : stepsByOrder.keySet().stream().sorted().collect(Collectors.toList())) {
                List<FileTypeRelationshipResponseDTO> stepsForService = stepsByOrder.get(stepOrder);
                if (stepsForService.isEmpty()) {
                    continue;
                }

                // Prepare service task
                FileTypeRelationshipResponseDTO serviceStep = stepsForService.get(0);
                WorkflowProcess workflowProcess = fileTypeRelationshipService.getWorkflowProcessById(serviceStep.getWorkflowProcessId());
                List<WorkflowStep> workflowStepsForSave = stepsForService.stream()
                        .map(step -> fileTypeRelationshipService.getWorkflowStepById(step.getStepOrder(), step.getWorkflowProcessId()))
                        .collect(Collectors.toList());

                ServiceTask task = new ServiceTask(serviceStep, workflowProcess, workflowStepsForSave, fileDownloadId, batchId, businessDate, version, workflowId);

                // Execute service task
                retryManager.executeTask(task);
            }
        } catch (Exception e) {
            System.err.println("Error executing workflow: " + e.getMessage());
        }
    }
}

