package com.example.demo.service;

import com.example.demo.dto.WorkflowDTO;
import com.example.demo.mapper.WorkflowMapper;
import com.example.demo.model.Workflow;
import com.example.demo.repository.WorkflowRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class WorkflowService {

    private final WorkflowRepository workflowRepository;
    private final WorkflowMapper workflowMapper;

    public WorkflowService(WorkflowRepository workflowRepository, WorkflowMapper workflowMapper) {
        this.workflowRepository = workflowRepository;
        this.workflowMapper = workflowMapper;
    }

    public List<Workflow> getAllWorkflows() {
        return workflowRepository.findAll();
    }

    public WorkflowDTO createWorkflow(WorkflowDTO workflowDTO) {

        Workflow workflow = workflowMapper.toEntity(workflowDTO);
        WorkflowDTO createdWorkflowDTO = workflowMapper.toDTO(workflowRepository.save(workflow));
        return createdWorkflowDTO;
    }

    public Workflow getWorkflowById(Long id) {
        return workflowRepository.findById(id).orElse(null);
    }

    public List<WorkflowDTO> getAllWorkflowDTOs() {
        return getAllWorkflows().stream()
                .map(workflowMapper::toDTO)
                .collect(Collectors.toList());
    }

    public WorkflowDTO getWorkflowDTOById(Long id) {
        Workflow workflow = getWorkflowById(id);
        return workflowMapper.toDTO(workflow);
    }

    public WorkflowDTO updateWorkflow(Long id, WorkflowDTO workflowDTO) {
        Workflow existingWorkflow = getWorkflowById(id);
        if (existingWorkflow != null) {
            existingWorkflow.setWorkflowName(workflowDTO.getName());
            existingWorkflow.setDescription(workflowDTO.getDescription());
            Workflow updatedWorkflow = workflowRepository.save(existingWorkflow);
            return workflowMapper.toDTO(updatedWorkflow);
        }
        return null;
    }

    public boolean deleteWorkflow(Long id) {
        if (workflowRepository.existsById(id)) {
            workflowRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
