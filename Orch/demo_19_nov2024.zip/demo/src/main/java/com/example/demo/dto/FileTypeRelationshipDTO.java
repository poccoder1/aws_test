package com.example.demo.dto;

import lombok.Data;

@Data
public class FileTypeRelationshipDTO {
    private Long ftRelationId;
    private String inputFileType;
    private String outputFileType;
    private Integer stepOrder;
    private Long workflowProcessId;
}
