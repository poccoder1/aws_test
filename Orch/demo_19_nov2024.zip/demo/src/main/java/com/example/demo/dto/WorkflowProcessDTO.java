package com.example.demo.dto;

import lombok.Data;

@Data
public class WorkflowProcessDTO {
    private Long workflowProcessId;
    private Long workflowId;
    private Long processId;
}
