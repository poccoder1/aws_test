package com.example.demo.dto;

import com.example.demo.model.WorkflowProcess;
import com.example.demo.model.WorkflowStep;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ServiceTask {

    final FileTypeRelationshipResponseDTO serviceStep;
    final WorkflowProcess workflowProcess;
    final List<WorkflowStep> steps;
    final UUID fileDownloadId;
    final String batchId;
    final LocalDate businessDate;
    final int version;
    final String workflowId;
    final Map<String, Object> context = new ConcurrentHashMap<>();

    ServiceTask(FileTypeRelationshipResponseDTO serviceStep, WorkflowProcess workflowProcess,
                List<WorkflowStep> steps, UUID fileDownloadId, String batchId,
                LocalDate businessDate, int version, String workflowId) {
        this.serviceStep = serviceStep;
        this.workflowProcess = workflowProcess;
        this.steps = steps;
        this.fileDownloadId = fileDownloadId;
        this.batchId = batchId;
        this.businessDate = businessDate;
        this.version = version;
        this.workflowId = workflowId;
    }
}
