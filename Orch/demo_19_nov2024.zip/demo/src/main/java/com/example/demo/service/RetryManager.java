package com.example.demo.service;

import java.util.concurrent.*;

public class RetryManager {

    private final WorkflowExecutor workflowExecutor;
    private final ScheduledExecutorService retryExecutor;
    private final Map<String, BlockingQueue<ServiceTask>> retryQueues;

    public RetryManager(ServiceCaller serviceCaller, FileProcessStatusService fileProcessStatusService) {
        this.workflowExecutor = new WorkflowExecutor(serviceCaller, fileProcessStatusService);
        this.retryExecutor = Executors.newScheduledThreadPool(10);
        this.retryQueues = new ConcurrentHashMap<>();
    }

    /**
     * Executes a task and schedules retries if it fails.
     */
    public void executeTask(ServiceTask task) {
        if (workflowExecutor.executeTask(task)) {
            // Remove from retry queue on success
            getRetryQueue(task.workflowId).remove(task);
        } else {
            // Schedule retry
            scheduleRetry(task);
        }
    }

    private void scheduleRetry(ServiceTask task) {
        BlockingQueue<ServiceTask> retryQueue = getRetryQueue(task.workflowId);
        retryQueue.offer(task);
        retryExecutor.schedule(() -> retryTask(task), 10, TimeUnit.MINUTES);
        System.out.println("Scheduled retry for service: " + task.serviceStep.getServiceName());
    }

    private void retryTask(ServiceTask task) {
        BlockingQueue<ServiceTask> retryQueue = getRetryQueue(task.workflowId);
        if (retryQueue.contains(task)) {
            executeTask(task);
        }
    }

    private BlockingQueue<ServiceTask> getRetryQueue(String workflowId) {
        return retryQueues.computeIfAbsent(workflowId, id -> new LinkedBlockingQueue<>());
    }
}
