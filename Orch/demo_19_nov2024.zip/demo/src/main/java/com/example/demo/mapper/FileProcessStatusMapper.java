package com.example.demo.mapper;

import com.example.demo.dto.FileProcessStatusDTO;
import com.example.demo.model.FileProcessStatus;
import org.springframework.stereotype.Component;

@Component
public class FileProcessStatusMapper {

    public FileProcessStatusDTO toDTO(FileProcessStatus fileProcessStatus) {
        FileProcessStatusDTO dto = new FileProcessStatusDTO();
        dto.setProcessId(fileProcessStatus.getWorkflowProcess().getProcess().getProcessId());
        dto.setInputFileType(fileProcessStatus.getInputFileType());
        dto.setStatus(fileProcessStatus.getStatus());
        dto.setStartTime(fileProcessStatus.getStartTime());
        dto.setEndTime(fileProcessStatus.getEndTime());
        return dto;
    }
}
